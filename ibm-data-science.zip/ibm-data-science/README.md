# IBM Data Science Capstone – SpaceX Falcon 9 Landing Prediction
Notebooks: EDA with SQL, EDA with visualization, Folium launch-site map, ML prediction.
`dash_app/` Plotly Dash dashboard · `data/Spacex.csv` dataset · `images/` charts · `scripts/` analysis code · final report PDF.
