import sys, pickle
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape
from reportlab.lib.utils import simpleSplit, ImageReader
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
GH=sys.argv[1] if len(sys.argv)>1 else 'https://github.com/YOUR-USERNAME/spacex-capstone'
S,R,st,pb,bb,P=pickle.load(open('res.pkl','rb'))
bb=bb.to_dict('index'); pb=pb.to_dict('index')
W,H=13.333*72,7.5*72
c=canvas.Canvas('/mnt/user-data/outputs/Data_Science_Capstone_Project_Report.pdf',pagesize=(W,H))
c.setTitle('Data Science Capstone Project Report - SpaceX Falcon 9 First Stage Landing')
NAVY=colors.HexColor('#0b2545'); BLUE=colors.HexColor('#3b6ea5'); ORG=colors.HexColor('#e07a00'); GREY=colors.HexColor('#444444')
pg=[0]
def slide(title,sub=None):
    if pg[0]: c.showPage()
    pg[0]+=1
    c.setFillColor(NAVY); c.rect(0,H-70,W,70,fill=1,stroke=0)
    c.setFillColor(colors.white); c.setFont('Helvetica-Bold',26); c.drawString(36,H-46,title)
    c.setFillColor(ORG); c.rect(0,H-74,W,4,fill=1,stroke=0)
    c.setFillColor(GREY); c.setFont('Helvetica',9); c.drawRightString(W-30,16,f'{pg[0]}'); c.drawString(36,16,'SpaceX Falcon 9 – Applied Data Science Capstone')
    if sub:
        c.setFont('Helvetica-Oblique',13); c.setFillColor(BLUE); c.drawString(36,H-96,sub)
def bullets(items,x=40,y=None,w=None,size=15,lead=1.3,gap=7):
    size=size*(1.2 if (w is None or w>800) else 1.08); y=y or H-125; w=w or W-2*x
    for it in items:
        sub=it.startswith('  ')
        t=it.strip(); xs=x+(22 if sub else 0); fs=size-2 if sub else size
        c.setFont('Helvetica',fs); c.setFillColor(colors.black)
        lines=simpleSplit(t,'Helvetica',fs,w-(xs-x)-16)
        c.setFillColor(ORG if not sub else BLUE); c.circle(xs+3,y+fs*0.33,2.5,fill=1,stroke=0); c.setFillColor(colors.black)
        for l in lines:
            c.drawString(xs+14,y,l); y-=fs*lead
        y-=gap
    return y
def img(p,x,y,w,h=None):
    ir=ImageReader(f'img/{p}.png'); iw,ih=ir.getSize(); h=h or w*ih/iw
    if h>H-y-80 and False: pass
    c.drawImage(ir,x,y,w,h,mask='auto'); return h
def caption(t,x,y,w,size=12):
    c.setFont('Helvetica-Oblique',size); c.setFillColor(GREY)
    for l in simpleSplit(t,'Helvetica-Oblique',size,w): c.drawString(x,y,l); y-=size*1.3
def url(x=40,y=34,label='GitHub:'):
    c.setFont('Helvetica-Bold',10); c.setFillColor(BLUE); c.drawString(x,y,f'{label} {GH}')
    c.linkURL(GH,(x,y-3,x+560,y+10))
def tbl(data,x,y,colw,fs=9,hdr=BLUE):
    fs=fs*1.4; colw=[w*1.4 for w in colw]
    t=Table(data,colWidths=colw)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),hdr),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),fs),('GRID',(0,0),(-1,-1),0.4,colors.grey),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#eef3f9')]),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
    w_,h_=t.wrapOn(c,W,H); t.drawOn(c,x,y-h_); return h_
def box(txt,x,y,w,h,fill=BLUE,fs=11):
    c.setFillColor(fill); c.roundRect(x,y,w,h,8,fill=1,stroke=0); c.setFillColor(colors.white); c.setFont('Helvetica-Bold',fs)
    ls=simpleSplit(txt,'Helvetica-Bold',fs,w-12); yy=y+h/2+(len(ls)-1)*fs*0.6-fs*0.3
    for l in ls: c.drawCentredString(x+w/2,yy,l); yy-=fs*1.2
def arrow(x1,y,x2):
    c.setStrokeColor(GREY); c.setLineWidth(2); c.line(x1,y,x2-6,y); c.setFillColor(GREY); p=c.beginPath(); p.moveTo(x2,y); p.lineTo(x2-9,y+5); p.lineTo(x2-9,y-5); p.close(); c.drawPath(p,fill=1,stroke=0)
def flow(steps,y,fill=BLUE,bw=140,bh=62):
    n=len(steps); gap=(W-80-n*bw)/(n-1); x=40
    for i,s in enumerate(steps):
        box(s,x,y,bw,bh,fill); 
        if i<n-1: arrow(x+bw+3,y+bh/2,x+bw+gap-3)
        x+=bw+gap
site=R['site']; res=R['res']; n=R['n']; best=R['best']
KSC=site['KSC LC-39A']; SL=site['CCAFS SLC-40']; LC=site['CCAFS LC-40']; V=site['VAFB SLC-4E']
# ---------- 1 title
pg[0]=1
c.setFillColor(NAVY); c.rect(0,0,W,H,fill=1,stroke=0); c.setFillColor(ORG); c.rect(0,H/2-6,W,6,fill=1,stroke=0)
c.setFillColor(colors.white); c.setFont('Helvetica-Bold',40); c.drawString(60,H/2+60,'Data Science Capstone Project Report')
c.setFont('Helvetica',22); c.drawString(60,H/2+22,'Predicting SpaceX Falcon 9 First-Stage Landing Success')
c.setFont('Helvetica',14); c.drawString(60,H/2-50,'Applied Data Science Capstone – IBM'); c.drawString(60,H/2-72,'Author: [Your name]    Date: October 31, 2026')
c.setFont('Helvetica',12); c.drawString(60,60,f'GitHub: {GH}'); c.linkURL(GH,(60,56,500,72))
# ---------- 2 exec summary
slide('Executive Summary')
y=bullets([
 'Problem: can we predict whether a Falcon 9 first stage will land successfully, so a competitor can estimate launch cost (SpaceX ~$62M vs. ~$165M+ for others)?',
 'Methodology: data collection (SpaceX REST API + Wikipedia web scraping) → data wrangling (landing-outcome label) → EDA with SQL and visualization → interactive analytics (Folium map, Plotly Dash) → classification models.',
 f'Data: {n} Falcon 9 launches, {R["years"][0]}–{R["years"][1]}. Overall landing success rate: {R["rate"]*100:.0f}%.',
 f'EDA results: success rate rose from {R["yr"][R["years"][0]]:.0f}% in {R["years"][0]} to {R["yr"][R["years"][1]]:.0f}% in {R["years"][1]}. KSC LC-39A has the best site success rate ({KSC["rate"]:.0f}%), CCAFS SLC-40 the most successful landings ({SL["succ"]:.0f}). Block 5 boosters land {bb["B5"]["mean"]*100:.0f}% of the time.',
 f'Predictive analysis: Logistic Regression, SVM, Decision Tree and KNN tuned with 10-fold grid search. Best test accuracy: {best} ({res[best][1]*100:.1f}%) on a {R["ntest"]}-launch hold-out set.'],size=16,gap=12)
url()
# ---------- 3 intro
slide('Introduction')
bullets([
 'Project background: SpaceX advertises Falcon 9 launches at about $62 million; other providers charge upward of $165 million. Much of the saving comes from reusing the first stage.',
 'If we can predict whether the first stage will land, we can estimate the launch cost – valuable information for an alternate company bidding against SpaceX.',
 'Problem statement: using public launch data, determine which factors (site, orbit, payload, booster version, experience) drive landing success and build a model that predicts landing outcome.',
 'Questions explored: Which launch site is most reliable? How does payload mass relate to success? Does success improve over time? Which classifier predicts landing best?'],size=16,gap=12)
# ---------- section methodology
slide('Methodology – Overview')
bullets(['Data collection methodology:','  SpaceX REST API (launch, rocket, launchpad, payload and core endpoints)','  Web scraping of Falcon 9 launch records from Wikipedia',
 'Data wrangling: cleaned missing values, built the binary `Class` label from the landing outcome',
 'Exploratory data analysis (EDA): SQL queries and visualization (matplotlib/seaborn)',
 'Interactive visual analytics: Folium maps and a Plotly Dash dashboard',
 'Predictive analysis (classification): standardized features, train/test split (80/20), GridSearchCV (cv=10) for four models, evaluated on accuracy and confusion matrix'],size=15)
# ---------- 5 API
slide('Data Collection – SpaceX API')
flow(['GET api.spacexdata.com /v4/launches/past','Parse JSON → DataFrame','Look up IDs: rocket, launchpad, payloads, cores','Keep Falcon 9, single core/payload','Build dataset (date, booster, site, payload, orbit, outcome)'],H-210,bw=140)
bullets(['Key phrases: requests.get(), response.json(), pd.json_normalize(), helper functions getBoosterVersion(), getLaunchSite(), getPayloadData(), getCoreData()',
 'Filtered out Falcon 1 launches and launches with multiple cores or payloads; converted dates and restricted to launches up to the cut-off date'],y=H-300,size=14)
caption('Flowchart summarises the standard lab workflow used for the API collection notebook.',40,60,W-80)
url()
# ---------- 6 scraping
slide('Data Collection – Web Scraping')
flow(['HTTP GET Wikipedia "List of Falcon 9 and Falcon Heavy launches"','BeautifulSoup parses the HTML','Find launch tables (class "wikitable plainrowheaders collapsible")','Extract header + each row (flight no., date, booster, site, payload, orbit, outcome)','Build DataFrame → CSV'],H-210,bw=140,fill=colors.HexColor('#2e8b57'))
bullets(['Key phrases: requests.get(), BeautifulSoup(), find_all("table"), extract_column_from_header(), pd.DataFrame(launch_dict)',
 'Helper functions cleaned dates/times, booster versions and landing-status cells'],y=H-300,size=14)
caption('Flowchart summarises the standard lab workflow used for the web-scraping notebook.',40,60,W-80)
url()
# ---------- 7 wrangling
slide('Data Wrangling Methodology')
flow(['Load launch data','Handle missing values & whitespace','Count launches per site / orbit','Map landing outcome → class (1 / 0)','Export clean dataset'],H-200,bw=130,fill=NAVY)
bullets(['Calculated the number of launches per site, per orbit and the outcome counts (value_counts()).',
 'Landing outcomes: "Success", "Success (drone ship)" and "Success (ground pad)" are the positive class = 1. "Failure" variants, "No attempt", "Controlled/Uncontrolled (ocean)" and "Precluded" are the negative class = 0.',
 f'Resulting label: Class = 1 for {R["rate"]*100:.0f}% of the {n} launches. Also created FlightNumber, Year and booster-family (v1.0, v1.1, FT, B4, B5) features.',
 'Categorical features (Orbit, Launch Site, Booster) were one-hot encoded and numeric features standardized for modelling.'],y=H-290,size=14)
url()
# ---------- 8 EDA viz summary
slide('EDA with Data Visualization')
bullets(['Scatter plots (Flight Number vs Launch Site, Payload vs Launch Site, Flight Number vs Orbit, Payload vs Orbit): show how outcome (colour) relates to experience, payload and destination.',
 'Bar chart (success rate by orbit): compares reliability of each orbit type at a glance.',
 'Line chart (yearly success trend): shows learning curve and technology improvement over 2010–2020.',
 'Feature engineering: booster family, Year and one-hot encoded Orbit/Site features were prepared for the models.'],size=15,gap=12)
url()
# ---------- 9 EDA SQL summary
slide('EDA with SQL')
bullets(['Connected to the dataset with SQL (SQLite) and ran ten queries:',
 '  Unique launch site names',
 '  Five records where the launch site begins with "CCA"',
 '  Total payload mass carried for customer NASA (CRS)',
 '  Average payload mass carried by booster version F9 v1.1',
 '  Date of first successful landing on a ground pad',
 '  Boosters with drone-ship success and payload between 4,000 and 6,000 kg',
 '  Total number of successful and failed mission outcomes',
 '  Booster versions that carried the maximum payload (sub-query)',
 '  2015 drone-ship landing failures (month, booster, site)',
 '  Rank of landing outcomes between 2010-06-04 and 2017-03-20'],size=14,gap=3)
url()
# ---------- 10 interactive summary
slide('Build an Interactive Map with Folium / Dashboard with Plotly Dash')
bullets(['Folium map: marked all launch sites (Circle + Marker with site label), added green/red markers for successful/failed launches in a MarkerCluster, and used MousePosition + PolyLine + distance markers to measure proximity to coastline, railway, highway and the nearest city.',
 'Why: shows launch-site geography (near the equator for extra rotational speed, close to the coast so failures fall over water, away from cities).',
 'Plotly Dash: dropdown for launch site, pie chart of success counts, range slider for payload mass and scatter plot of payload vs outcome coloured by booster version.',
 'Why: lets stakeholders filter by site and payload range and see patterns interactively.'],size=14,gap=10)
url(label='GitHub (Folium & Dash notebooks / app):')
# ---------- EDA result slides
slide('EDA with Visualization – Flight Number vs Launch Site')
img('fn_site',40,100,520); bullets([f'Later flights (higher flight numbers) succeed far more often, at every site.',f'Early flights from CCAFS LC-40 mostly failed; recent landings are concentrated at CCAFS SLC-40 and KSC LC-39A.','VAFB SLC-4E (16 launches) flies Polar LEO, SSO and LEO missions; its success rate rose from 50% to 75% between early and later flights.','CCAFS LC-40 and SLC-40 are the same pad under two names in this dataset (flights 1–28 vs 45–100).'],x=590,y=H-150,w=330,size=14)
slide('EDA with Visualization – Payload vs Launch Site')
img('pl_site',40,100,520); bullets(['Payloads above 9,000 kg: CCAFS SLC-40 10 launches (90% success), KSC LC-39A 10 (80%), VAFB SLC-4E 7 (71%).','CCAFS LC-40 never carried more than 5,271 kg.','Light payloads (<2,000 kg) are mostly early launches (median year 2015) and have the lowest success rate.'],x=590,y=H-150,w=330,size=14)
slide('EDA with Visualization – Success Rate by Orbit')
o=R['orb']; top=[k for k,v in o.items() if v==max(o.values())]
img('orbit_bar',40,100,520); bullets(['SSO (83%, 6 launches) and LEO (80%, 25 launches) have the highest success rates.','GTO (50% of 30 launches), Polar LEO (50%) and ISS missions (54%) are harder.','Orbits with only 1–3 launches (Sub-orbital 0%, HEO, MEO) are too small a sample to rank.'],x=590,y=H-150,w=330,size=14)
slide('EDA with Visualization – Flight Number vs Orbit')
img('fn_orbit',40,100,520); bullets(['LEO landings succeeded 62% in the first 50 flights and 88% afterwards – experience matters.','GTO has stayed at about 50% success because high-energy missions leave less fuel margin for landing.'],x=590,y=H-150,w=330,size=14)
slide('EDA with Visualization – Payload vs Orbit')
img('pl_orbit',40,100,520); bullets(['LEO carries the heaviest payloads (median 15,440 kg) with 80% success.','GTO median payload ≈5,000 kg, success 50%.','ISS missions are light (median ≈2,440 kg), 54% success; Polar LEO flights all carried 9,600 kg.'],x=590,y=H-150,w=330,size=14)
slide('EDA with Visualization – Launch Success Yearly Trend')
y_=R['yr']; img('yearly',40,100,520); bullets([f'Success rate: 0% through 2014, {y_[2015]:.0f}% in 2015, {y_[2016]:.0f}% in 2016, {y_[2017]:.0f}% in 2017, {y_[2019]:.0f}% in 2019, {y_[2020]:.0f}% in 2020.','Overall upward trend after the first landings in 2015, with a dip to 50% in 2018. (No launches in 2011.)'],x=590,y=H-150,w=330,size=14)
# ---------- SQL results
def q(n_,txt): return txt
slide('EDA with SQL – Launch Site Names and CCA Records')
c.setFont('Helvetica-Bold',13); c.setFillColor(NAVY); c.drawString(40,H-100,'Q1: SELECT DISTINCT Launch_Site FROM SPACEXTABLE')
tbl([['Launch_Site']]+[[s] for s in S['sites']],40,H-108,[200])
c.setFont('Helvetica-Bold',13); c.drawString(40,H-250,"Q2: ... WHERE Launch_Site LIKE 'CCA%' LIMIT 5")
tbl([['Date','Booster_Version','Launch_Site','Payload (kg)']]+[[str(r.Date.date()),r.Booster_Version,r.Site if hasattr(r,'Site') else r.Launch_Site if hasattr(r,'Launch_Site') else '',int(r.Payload)] for r in S['cca'].rename(columns={'Launch_Site':'Site'}).itertuples()],40,H-258,[110,170,140,100])
c.setFont('Helvetica',13); c.setFillColor(colors.black); c.drawString(40,60,'Four distinct sites. All five earliest "CCA" launches were from CCAFS LC-40 with F9 v1.0 boosters.'); url(y=36)
slide('EDA with SQL – Payload Mass Queries')
c.setFont('Helvetica-Bold',13); c.setFillColor(NAVY); c.drawString(40,H-100,"Q3: SELECT SUM(PAYLOAD_MASS__KG_) ... WHERE Customer = 'NASA (CRS)'")
tbl([['Total payload mass (kg)'],[f'{int(S["crs"]):,}']],40,H-108,[250],fs=11)
c.setFont('Helvetica-Bold',13); c.drawString(40,H-215,"Q4: SELECT AVG(PAYLOAD_MASS__KG_) ... WHERE Booster_Version LIKE 'F9 v1.1%'")
tbl([['Average payload mass (kg)'],[f'{S["avgv11"]:,.2f}']],40,H-223,[250],fs=11)
c.setFont('Helvetica-Bold',13); c.drawString(40,H-330,'Q5: Total payload carried by all launches')
tbl([['Total payload mass (kg)'],[f'{int(S["tot"]):,}']],40,H-338,[250],fs=11)
c.setFont('Helvetica',13); c.setFillColor(colors.black); c.drawString(40,60,'NASA (CRS) missions carried 45,596 kg in total; F9 v1.1 boosters averaged about 2,535 kg per mission.'); url(y=36)
slide('EDA with SQL – Landing Success Queries')
c.setFont('Helvetica-Bold',13); c.setFillColor(NAVY); c.drawString(40,H-100,"Q6: MIN(Date) WHERE Landing_Outcome = 'Success (ground pad)'")
tbl([['First successful ground-pad landing'],[str(S['firstgp'])]],40,H-108,[280],fs=11)
c.setFont('Helvetica-Bold',13); c.drawString(40,H-215,'Q7: Drone-ship success with payload between 4,000 and 6,000 kg')
tbl([['Booster_Version']]+[[b] for b in S['drone']],40,H-223,[280],fs=11)
c.setFont('Helvetica-Bold',13); c.drawString(480,H-100,'Q8: Mission outcome counts')
tbl([['Mission_Outcome','Count']]+[[k,int(v)] for k,v in S['mission'].items()],480,H-108,[200,70],fs=11)
c.setFont('Helvetica',13); c.setFillColor(colors.black); c.drawString(40,60,'First ground-pad landing: 22 Dec 2015. Out of 101 missions, 100 were successful and 1 failed in flight.'); url(y=36)
slide('EDA with SQL – Payload, 2015 Failures and Rankings')
c.setFont('Helvetica-Bold',13); c.setFillColor(NAVY); c.drawString(40,H-100,f'Q9: Boosters that carried the maximum payload ({int(S["mx"]):,} kg)')
mp=S['maxp']; tbl([['Booster_Version']]+[[b] for b in mp[:6]]+[[f'... {len(mp)} launches in total, all Block 5 (B5)']],40,H-108,[250],fs=10)
c.setFont('Helvetica-Bold',13); c.drawString(40,H-310,'Q10: 2015 drone-ship landing failures')
tbl([['Month','Booster_Version','Launch_Site']]+[[r.Date.strftime('%B'),r.Booster_Version,r.Site] for r in S['fail2015'].itertuples()],40,H-318,[80,130,110],fs=10)
c.setFont('Helvetica-Bold',13); c.drawString(440,H-100,'Q11: Landing outcomes ranked, 2010-06-04 to 2017-03-20')
tbl([['Landing_Outcome','Count']]+[[k,int(v)] for k,v in S['rank'].items()],440,H-108,[200,70],fs=10)
url(y=36)
slide('EDA with SQL – Success Rates by Launch Site and Year')
c.setFont('Helvetica-Bold',13); c.setFillColor(NAVY); c.drawString(40,H-100,'Landing success by launch site')
tbl([['Launch site','Launches','Successful landings','Success rate']]+[[k,int(v['launches']),int(v['succ']),f'{v["rate"]:.1f}%'] for k,v in site.items()],40,H-108,[130,80,130,100],fs=11)
c.setFont('Helvetica-Bold',13); c.drawString(40,H-270,'Landing success by year')
yy=R['yr']; yrs=sorted(yy); tbl([['Year']+[str(k) for k in yrs],['Success rate']+[f'{yy[k]:.0f}%' for k in yrs]],40,H-278,[75]+[55]*len(yrs),fs=10)
c.setFont('Helvetica',13); c.setFillColor(colors.black)
c.drawString(40,70,f'KSC LC-39A has the best success rate ({KSC["rate"]:.0f}%); CCAFS SLC-40 has the most successful landings ({int(SL["succ"])}).'); url(y=36)
# ---------- Folium
slide('Interactive Map – All Launch Sites')
img('map_all',40,120,540); bullets(['All four launch sites are on the US coast: three in Florida (CCAFS LC-40, CCAFS SLC-40, KSC LC-39A) and one in California (VAFB SLC-4E).','Florida sites are close to the equator, which gives extra eastward rotational speed; Vandenberg supports polar launches.','All sites are right next to the coast, so rockets fly over the ocean.'],x=590,y=H-150,w=330,size=13)
caption('Schematic plot of site coordinates (the notebook map uses OpenStreetMap tiles).',40,70,520,11); url(y=36,label='GitHub (Folium notebook):')
slide('Interactive Map – Launch Records per Site')
img('map_records',40,160,880); bullets([f'Green markers = successful landings, red = failed. KSC LC-39A: {int(KSC["succ"])} of {int(KSC["launches"])} green ({KSC["rate"]:.0f}%).',f'CCAFS LC-40 has mostly red markers ({int(LC["succ"])} of {int(LC["launches"])} green) – these are the early launches.'],x=40,y=140,w=880,size=13)
url(y=36,label='GitHub (Folium notebook):')
slide('Interactive Map – Proximity Analysis')
img('map_prox',40,110,540); bullets([f'Coastline: ≈{P["Coastline"]} km, railway ≈{P["Railway"]} km, highway ≈{P["Highway"]} km from CCAFS LC-40.',f'Nearest city (Melbourne): ≈{P["Melbourne (city)"]} km.','Sites are close to coast, rail and highway for transport of rockets and cargo, but far from cities for safety.','Distances computed with the haversine formula (calculate_distance).'],x=600,y=H-150,w=320,size=13)
caption('Proximity point coordinates are approximate; confirm with MousePosition in the Folium notebook.',40,80,540,11); url(y=36,label='GitHub (Folium notebook):')
# ---------- Dash
slide('Plotly Dash – Success Pie Chart (All Sites)')
img('pie_all',40,100,440); bullets([f'CCAFS SLC-40 accounts for the largest share of successful landings ({SL["succ"]/sum(v["succ"] for v in site.values())*100:.1f}%), followed by KSC LC-39A ({KSC["succ"]/sum(v["succ"] for v in site.values())*100:.1f}%).','CCAFS LC-40 has the smallest share of successes (early missions).'],x=520,y=H-150,w=400,size=14)
url(y=36,label='GitHub (Dash app):')
slide('Plotly Dash – Highest Success-Ratio Site')
img('pie_ksc',40,100,440); bullets([f'KSC LC-39A has the highest success ratio: {KSC["rate"]:.0f}% success ({int(KSC["succ"])} of {int(KSC["launches"])} launches).','Selecting a single site in the dropdown shows success (1) vs failed (0) counts for that site.'],x=520,y=H-150,w=400,size=14)
url(y=36,label='GitHub (Dash app):')
slide('Plotly Dash – Payload vs Launch Outcome (All Sites)')
img('sc_all',40,100,560); pbq=R['pb']
bullets(['Highest success rate: 8,000–10,000 kg (71%, only 7 launches); best well-populated range 2,000–4,000 kg (64% of 28).','Lowest success rate: 0–2,000 kg (27%) – dominated by early launches.',f'Booster with highest rate: Block 5 ({bb["B5"]["mean"]*100:.0f}% over {int(bb["B5"]["size"])} launches); v1.0 and v1.1 never landed.'],x=620,y=H-150,w=300,size=12)
url(y=36,label='GitHub (Dash app):')
slide('Plotly Dash – Payload Range Slider and Site Filter')
img('sc_range',40,230,420,); img('sc_ksc',480,230,420)
caption('Left: payload slider set to 2,000–6,000 kg. Right: dropdown set to KSC LC-39A. Charts reproduce the dashboard callbacks (colour = booster family).',40,200,860,12)
bullets(['2,000–6,000 kg: 63% success over 51 launches (Block 5 88%, FT 72%, v1.1 0%). KSC LC-39A: 12 of 13 launches in this range landed (92%).'],x=40,y=150,w=860,size=13)
url(y=36,label='GitHub (Dash app):')
# ---------- ML
slide('Predictive Analysis (Classification) – Methodology')
flow(['Class label as target','Standardize features','Train/test split 80/20 (random_state=2)','GridSearchCV, cv=10','Evaluate accuracy + confusion matrix'],H-200,bw=130,fill=NAVY)
bullets(['Models: Logistic Regression, Support Vector Machine, Decision Tree, K-Nearest Neighbours.','Features: FlightNumber, Payload, Year, one-hot Orbit / Launch Site / Booster family.','Best hyper-parameters: '+'; '.join(f'{k}: '+', '.join(f'{a}={b if not isinstance(b,float) else round(b,3)}' for a,b in v.items()) for k,v in R['params'].items())],y=H-280,size=12)
url(y=36,label='GitHub (ML notebook):')
slide('Classification Accuracy')
img('ml_acc',40,100,520)
tbl([['Model','CV accuracy','Test accuracy']]+[[k,f'{v[0]*100:.1f}%',f'{v[1]*100:.1f}%'] for k,v in res.items()],585,H-130,[105,68,68],fs=8)
bullets([f'{best} reached the highest test accuracy ({res[best][1]*100:.1f}%); KNN had the highest cross-validation accuracy ({res["KNN"][0]*100:.1f}%).','The test set has only 21 launches, so one extra correct prediction changes accuracy by ~4.8 points.'],x=590,y=H-290,w=330,size=12)
url(y=36,label='GitHub (ML notebook):')
slide('Confusion Matrix – Best Model')
img('ml_cm',40,130,540)
bullets([f'{best}: 8 true negatives, 2 false positives, 1 false negative, 10 true positives (18/21 correct = 85.7%).','The main error type is predicting a landing that does not happen (false positives).','For comparison, Logistic Regression misses more successful landings (4 false negatives).'],x=600,y=H-150,w=320,size=13)
url(y=36,label='GitHub (ML notebook):')
slide('Best Model, Conclusions and Insights')
imp=R['imp']
bullets([f'Best model: {best} (max_depth=4) – highest hold-out accuracy and interpretable. KNN is a close second in cross-validation, so the models are statistically very similar on this small data set.',
 f'Most important feature: FlightNumber ({imp["FlightNumber"]*100:.0f}% of importance), then Block 5 booster ({imp["Booster_B5"]*100:.0f}%) and payload ({imp["Payload"]*100:.0f}%) – landing success reflects accumulated experience and hardware maturity.',
 f'Success rose from {R["yr"][R["years"][0]]:.0f}% ({R["years"][0]}) to {R["yr"][R["years"][1]]:.0f}% ({R["years"][1]}); KSC LC-39A ({KSC["rate"]:.0f}%) is the most reliable site.',
 'Innovative insight: a competitor can treat landing probability as a cost variable – a Block 5 booster launched from a Florida site is priced like a reusable launch, while an unproven stage should be costed as expendable.',
 'Next steps: add more features (landing hardware such as grid fins/legs, reuse count, weather), collect more launches, and use cross-validated ensembles to reduce small-sample noise.'],size=14,gap=9)
url(y=36)
slide('Appendix – Key Figures')
tbl([['Metric','Value']]+[['Launches analysed',n],['Overall landing success rate',f'{R["rate"]*100:.1f}%'],['Best site by rate',f'KSC LC-39A ({KSC["rate"]:.0f}%)'],['Most successful landings',f'CCAFS SLC-40 ({int(SL["succ"])})'],['Best booster family',f'Block 5 ({bb["B5"]["mean"]*100:.0f}%)'],['Best model (test accuracy)',f'{best} ({res[best][1]*100:.1f}%)']],40,H-110,[260,220],fs=12)
url(y=36)
c.save(); print('pages',pg[0])
