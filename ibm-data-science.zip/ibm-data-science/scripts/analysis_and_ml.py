import pandas as pd, numpy as np, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt, seaborn as sns
from math import radians, sin, cos, sqrt, atan2
sns.set_theme(style='whitegrid')
d=pd.read_csv('/mnt/user-data/uploads/Spacex.csv')
for c in d.select_dtypes('object'): d[c]=d[c].str.strip()
d['Date']=pd.to_datetime(d['Date']); d['Year']=d.Date.dt.year
d['FlightNumber']=range(1,len(d)+1)
d['Payload']=d.PAYLOAD_MASS__KG_
d['Class']=d.Landing_Outcome.str.startswith('Success').astype(int)
d['Site']=d.Launch_Site
def fam(b):
    for k in ['v1.0','v1.1','FT','B4','B5']:
        if k in b: return k
    return 'Other'
d['Booster']=d.Booster_Version.map(fam)
print(d.Year.min(),d.Year.max(), d.Booster.value_counts().to_dict())
R={}
R['years']=(int(d.Year.min()),int(d.Year.max())); R['n']=len(d)
R['rate']=d.Class.mean()
# ---- SQL-style results
S={}
S['sites']=d.Site.unique().tolist()
S['cca']=d[d.Site.str.startswith('CCA')][['Date','Booster_Version','Site','Payload']].head(5)
S['crs']=d[d.Customer=='NASA (CRS)'].Payload.sum()
S['avgv11']=d[d.Booster_Version.str.contains('v1.1')].Payload.mean()
S['firstgp']=d[d.Landing_Outcome=='Success (ground pad)'].Date.min().date()
S['drone']=d[(d.Landing_Outcome=='Success (drone ship)')&(d.Payload>4000)&(d.Payload<6000)].Booster_Version.tolist()
S['mission']=d.Mission_Outcome.str.replace(r' \(payload.*','',regex=True).value_counts()
mx=d.Payload.max(); S['maxp']=d[d.Payload==mx].Booster_Version.tolist(); S['mx']=mx
S['fail2015']=d[(d.Year==2015)&(d.Landing_Outcome=='Failure (drone ship)')][['Date','Booster_Version','Site']]
S['rank']=d[(d.Date>='2010-06-04')&(d.Date<='2017-03-20')].Landing_Outcome.value_counts()
S['tot']=d.Payload.sum()
S['pre']=d.groupby('Site').size(); 
for k,v in S.items(): print('\n',k,'\n',v)
# ---- EDA charts
def save(n): plt.tight_layout(); plt.savefig(f'img/{n}.png',dpi=150); plt.close()
pal={0:'#d9534f',1:'#2e8b57'}
fig,ax=plt.subplots(figsize=(8,4.2)); sns.scatterplot(data=d,x='FlightNumber',y='Site',hue='Class',palette=pal,s=60,ax=ax); ax.set_title('Flight Number vs Launch Site'); save('fn_site')
fig,ax=plt.subplots(figsize=(8,4.2)); sns.scatterplot(data=d,x='Payload',y='Site',hue='Class',palette=pal,s=60,ax=ax); ax.set_xlabel('Payload mass (kg)'); ax.set_title('Payload vs Launch Site'); save('pl_site')
orb=d.groupby('Orbit').Class.mean().sort_values(ascending=False)*100
fig,ax=plt.subplots(figsize=(8,4.2)); sns.barplot(x=orb.index,y=orb.values,color='#3b6ea5',ax=ax); ax.set_ylabel('Landing success rate (%)'); ax.set_title('Success rate by Orbit'); plt.xticks(rotation=30); save('orbit_bar')
fig,ax=plt.subplots(figsize=(8,4.2)); sns.scatterplot(data=d,x='FlightNumber',y='Orbit',hue='Class',palette=pal,s=60,ax=ax); ax.set_title('Flight Number vs Orbit'); save('fn_orbit')
fig,ax=plt.subplots(figsize=(8,4.2)); sns.scatterplot(data=d,x='Payload',y='Orbit',hue='Class',palette=pal,s=60,ax=ax); ax.set_xlabel('Payload mass (kg)'); ax.set_title('Payload vs Orbit'); save('pl_orbit')
yr=d.groupby('Year').Class.mean()*100
fig,ax=plt.subplots(figsize=(8,4.2)); ax.plot(yr.index,yr.values,marker='o',color='#3b6ea5'); ax.set_ylabel('Landing success rate (%)'); ax.set_xlabel('Year'); ax.set_title('Yearly success trend'); save('yearly')
R['orb']=orb.round(1).to_dict(); R['yr']=yr.round(1).to_dict()
# ---- site table
st=d.groupby('Site').agg(launches=('Class','size'),succ=('Class','sum')); st['rate']=st.succ/st.launches*100
print(st); R['site']=st.round(1).to_dict('index')
# ---- Dash-style charts (same logic as callbacks)
cols={'CCAFS LC-40':'#1f77b4','CCAFS SLC-40':'#ff7f0e','KSC LC-39A':'#2ca02c','VAFB SLC-4E':'#9467bd'}
def pie(ax,site=None):
    if site is None:
        v=d[d.Class==1].Site.value_counts(); ax.pie(v.values,labels=v.index,autopct='%1.1f%%',colors=[cols[i] for i in v.index]); ax.set_title('Total Successful Launches By Site')
    else:
        v=d[d.Site==site].Class.value_counts().reindex([1,0]).fillna(0); ax.pie(v.values,labels=['Success (1)','Failed (0)'],autopct='%1.1f%%',colors=['#2e8b57','#d9534f']); ax.set_title(f'Total Success Launches for site {site}')
fig,ax=plt.subplots(figsize=(5.5,4.2)); pie(ax); save('pie_all')
fig,ax=plt.subplots(figsize=(5.5,4.2)); pie(ax,'KSC LC-39A'); save('pie_ksc')
def sc(ax,lo,hi,site=None,t=''):
    x=d[(d.Payload>=lo)&(d.Payload<=hi)]; 
    if site: x=x[x.Site==site]
    sns.scatterplot(data=x,x='Payload',y='Class',hue='Booster',s=70,ax=ax); ax.set_yticks([0,1]); ax.set_xlabel('Payload mass (kg)'); ax.set_title(t); ax.set_xlim(-300,10300)
fig,ax=plt.subplots(figsize=(8,4)); sc(ax,0,10000,None,'Payload vs. Outcome for All Sites (0–10,000 kg)'); save('sc_all')
fig,ax=plt.subplots(figsize=(8,4)); sc(ax,2000,6000,None,'Payload vs. Outcome for All Sites (2,000–6,000 kg)'); save('sc_range')
fig,ax=plt.subplots(figsize=(8,4)); sc(ax,0,10000,'KSC LC-39A','Payload vs. Outcome for KSC LC-39A'); save('sc_ksc')
# payload bins & booster rates (dashboard questions)
dd=d[d.Payload<=10000].copy(); dd['bin']=pd.cut(dd.Payload,[-1,2000,4000,6000,8000,10000],labels=['0-2k','2-4k','4-6k','6-8k','8-10k'])
pb=dd.groupby('bin',observed=True).Class.agg(['size','mean']); print(pb)
bb=d.groupby('Booster').Class.agg(['size','mean']); print(bb); R['pb']=pb.round(3).to_dict('index'); R['bb']=bb.round(3).to_dict('index')
# ---- Folium-like maps (schematic)
sites={'CCAFS LC-40':(28.562302,-80.577356),'CCAFS SLC-40':(28.563197,-80.576820),'KSC LC-39A':(28.573255,-80.646895),'VAFB SLC-4E':(34.632834,-120.610746)}
fig,axs=plt.subplots(1,2,figsize=(9,4.2),gridspec_kw={'width_ratios':[1,1]})
ax=axs[0]; 
for i,(k,(la,lo)) in enumerate(sites.items()):
    if k.startswith('CCAFS'): ax.scatter(lo,la,s=140,color=cols[k],zorder=3,label=k); 
    elif k.startswith('KSC'): ax.scatter(lo,la,s=140,color=cols[k],zorder=3,label=k)
ax.set_title('Florida sites (NASA JSC style markers)'); ax.set_xlabel('Longitude'); ax.set_ylabel('Latitude'); ax.legend(fontsize=7)
ax=axs[1]; la,lo=sites['VAFB SLC-4E']; ax.scatter(lo,la,s=140,color=cols['VAFB SLC-4E'],label='VAFB SLC-4E'); ax.set_title('California site'); ax.set_xlabel('Longitude'); ax.legend(fontsize=7)
fig.suptitle('Launch site markers (schematic, no basemap)',fontsize=10); save('map_sites')
fig,ax=plt.subplots(figsize=(8,4.2))
for k,(la,lo) in sites.items():
    ax.scatter(lo,la,s=200,color=cols[k],zorder=3); ax.annotate(k,(lo,la),xytext=(6,6),textcoords='offset points',fontsize=8)
for k in sites:
    sub=d[d.Site==k]; 
ax.set_title('All four launch sites (lat/long)'); ax.set_xlabel('Longitude'); ax.set_ylabel('Latitude'); save('map_all')
# per-site success / fail marker panels (green/red markers, as in the cluster map)
fig,axs=plt.subplots(1,4,figsize=(10,3))
for ax,(k,sub) in zip(axs,d.groupby('Site')):
    vc=sub.Class.value_counts().reindex([1,0]).fillna(0)
    ax.bar(['Success','Failed'],vc.values,color=['#2e8b57','#d9534f']); ax.set_title(k,fontsize=9)
fig.suptitle('Launch records per site (green = success, red = failed markers)',fontsize=10); save('map_records')
def hav(a,b,c,e):
    R_=6373.0; a,b,c,e=map(radians,(a,b,c,e)); x=sin((c-a)/2)**2+cos(a)*cos(c)*sin((e-b)/2)**2; return R_*2*atan2(sqrt(x),sqrt(1-x))
la,lo=sites['CCAFS LC-40']
prox={'Coastline':(28.56367,-80.57163),'Railway':(28.57206,-80.58528),'Highway':(28.56334,-80.57674),'Melbourne (city)':(28.0836,-80.6081)}
P={k:round(hav(la,lo,*v),2) for k,v in prox.items()}; print(P); R['prox']=P
fig,ax=plt.subplots(figsize=(8,4.2)); ax.scatter(lo,la,s=220,color=cols['CCAFS LC-40'],zorder=4,label='CCAFS LC-40')
for (k,(a,b)),c in zip(prox.items(),['#0077b6','#6c757d','#e07a00','#7b2cbf']):
    ax.plot([lo,b],[la,a],'--',color=c); ax.scatter(b,a,s=60,color=c,zorder=3); ax.annotate(f'{k}: {P[k]} km',(b,a),xytext=(5,5),textcoords='offset points',fontsize=8)
ax.set_title('Proximity analysis from CCAFS LC-40'); ax.set_xlabel('Longitude'); ax.set_ylabel('Latitude'); ax.legend(); save('map_prox')
# ---- ML
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
X=pd.get_dummies(d[['FlightNumber','Payload','Orbit','Site','Booster','Year']],columns=['Orbit','Site','Booster']).astype(float); y=d.Class
Xs=StandardScaler().fit_transform(X)
Xtr,Xte,ytr,yte=train_test_split(Xs,y,test_size=0.2,random_state=2)
M={'Logistic Regression':(LogisticRegression(max_iter=1000),{'C':[0.01,0.1,1],'penalty':['l2'],'solver':['lbfgs']}),
 'SVM':(SVC(),{'kernel':['linear','rbf','poly','sigmoid'],'C':np.logspace(-3,3,5),'gamma':np.logspace(-3,3,5)}),
 'Decision Tree':(DecisionTreeClassifier(random_state=2),{'criterion':['gini','entropy'],'max_depth':[2,4,6,8,10],'min_samples_leaf':[1,2,4],'min_samples_split':[2,5,10]}),
 'KNN':(KNeighborsClassifier(),{'n_neighbors':list(range(1,11)),'p':[1,2],'algorithm':['auto']})}
res={};fits={}
for n,(m,g) in M.items():
    gs=GridSearchCV(m,g,cv=10).fit(Xtr,ytr); res[n]=(gs.best_score_,gs.score(Xte,yte)); fits[n]=gs; print(n,res[n],gs.best_params_)
fig,ax=plt.subplots(figsize=(7,4)); names=list(res); w=0.38; xs=np.arange(4)
ax.bar(xs-w/2,[res[n][0] for n in names],w,label='CV accuracy (train)',color='#3b6ea5'); ax.bar(xs+w/2,[res[n][1] for n in names],w,label='Test accuracy',color='#e07a00')
ax.set_xticks(xs); ax.set_xticklabels(names,fontsize=8); ax.set_ylim(0,1); ax.legend(); ax.set_title('Model accuracy'); save('ml_acc')
best=max(res,key=lambda n:(res[n][1],res[n][0])); R['best']=best
fig,axs=plt.subplots(1,2,figsize=(8,3.6))
for ax,n in zip(axs,[best,'Logistic Regression' if best!='Logistic Regression' else 'SVM']):
    ConfusionMatrixDisplay(confusion_matrix(yte,fits[n].predict(Xte)),display_labels=['did not land','landed']).plot(ax=ax,colorbar=False,cmap='Blues'); ax.set_title(n,fontsize=9)
save('ml_cm')
R['res']={k:[round(v[0],3),round(v[1],3)] for k,v in res.items()}; R['ntest']=len(yte); R['params']={n:{k:(float(v) if isinstance(v,np.floating) else v) for k,v in fits[n].best_params_.items()} for n in fits}
imp=pd.Series(fits['Decision Tree'].best_estimator_.feature_importances_,index=X.columns).sort_values(ascending=False).head(6); print(imp); R['imp']=imp.round(3).to_dict()
import pickle; pickle.dump((S,R,st,pb,bb,P),open('res.pkl','wb'))
