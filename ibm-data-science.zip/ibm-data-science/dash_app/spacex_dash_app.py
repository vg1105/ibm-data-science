import pandas as pd, dash
from dash import html, dcc
from dash.dependencies import Input, Output
import plotly.express as px
spacex_df = pd.read_csv('spacex_launch_dash.csv')
max_payload = spacex_df['Payload Mass (kg)'].max(); min_payload = spacex_df['Payload Mass (kg)'].min()
sites = spacex_df['Launch Site'].unique()
app = dash.Dash(__name__)
app.layout = html.Div([
    html.H1('SpaceX Launch Records Dashboard', style={'textAlign':'center'}),
    dcc.Dropdown(id='site-dropdown', options=[{'label':'All Sites','value':'ALL'}]+[{'label':s,'value':s} for s in sites],
                 value='ALL', placeholder='Select a Launch Site here', searchable=True),
    dcc.Graph(id='success-pie-chart'), html.P('Payload range (Kg):'),
    dcc.RangeSlider(id='payload-slider', min=0, max=10000, step=1000, marks={0:'0',2500:'2500',5000:'5000',7500:'7500',10000:'10000'}, value=[min_payload,max_payload]),
    dcc.Graph(id='success-payload-scatter-chart')])
@app.callback(Output('success-pie-chart','figure'), Input('site-dropdown','value'))
def pie(site):
    if site in ('ALL', None): return px.pie(spacex_df, values='class', names='Launch Site', title='Total Success Launches By Site')
    c = spacex_df[spacex_df['Launch Site']==site]['class'].value_counts().reset_index(); c.columns=['class','count']
    return px.pie(c, values='count', names='class', title=f'Total Success Launches for site {site}')
@app.callback(Output('success-payload-scatter-chart','figure'), [Input('site-dropdown','value'), Input('payload-slider','value')])
def scatter(site, rng):
    df = spacex_df[(spacex_df['Payload Mass (kg)']>=rng[0])&(spacex_df['Payload Mass (kg)']<=rng[1])]
    if site not in ('ALL', None): df = df[df['Launch Site']==site]
    return px.scatter(df, x='Payload Mass (kg)', y='class', color='Booster Version Category')
if __name__=='__main__': app.run()
